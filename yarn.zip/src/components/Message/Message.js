import React from 'react'

function Message(prop) {
    return (
        <div>
            {prop.text}
        </div>
    )
}

export default Message
